import javax.swing.text.*;

// =========================================================
//  Validador_Campos: lógica de validación y filtros.
//  Nomenclatura: snake_case en variables y parámetros.
// =========================================================
public class Validador_Campos {

    // --- Máximo de dígitos permitidos en el teléfono ---
    public static final int MAX_DIGITOS_TELEFONO = 15;

    // --- Entrada unificada de validación ---
    public static String validar(String valor, String tipo) {
        switch (tipo) {
            case "nombre":    return validar_nombre(valor);
            case "apellido":  return validar_apellido(valor);
            case "dni":       return validar_dni(valor);
            case "pasaporte": return validar_pasaporte(valor);
            case "telefono":  return validar_telefono(valor);
            case "cod_postal":return validar_codigo_postal(valor);
            case "domicilio": return validar_domicilio(valor);
            default:          return null;
        }
    }

    // ---------------------------------------------------------
    //  NOMBRE: solo letras, máx 20
    // ---------------------------------------------------------
    private static String validar_nombre(String v) {
        if (v.isEmpty())                             return "El nombre es obligatorio.";
        if (!v.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+"))  return "Solo se permiten letras.";
        if (v.length() > 20)                         return "Máximo 20 caracteres.";
        return null;
    }

    // ---------------------------------------------------------
    //  APELLIDO: ídem nombre
    // ---------------------------------------------------------
    private static String validar_apellido(String v) {
        if (v.isEmpty())                             return "El apellido es obligatorio.";
        if (!v.matches("[a-zA-ZáéíóúÁÉÍÓÚñÑ ]+"))  return "Solo se permiten letras.";
        if (v.length() > 20)                         return "Máximo 20 caracteres.";
        return null;
    }

    // ---------------------------------------------------------
    //  DNI: 8 dígitos, entre 10.000.000 y 60.000.000
    // ---------------------------------------------------------
    public static String validar_dni(String v) {
        if (v.isEmpty()) return null;
        if (!v.matches("\\d{8}"))                    return "Debe tener exactamente 8 dígitos.";
        long num = Long.parseLong(v);
        if (num < 10_000_000 || num > 60_000_000)   return "Debe estar entre 10.000.000 y 60.000.000.";
        return null;
    }

    // ---------------------------------------------------------
    //  PASAPORTE: 1 letra A-Z + 8 dígitos (ej: N39392288)
    // ---------------------------------------------------------
    public static String validar_pasaporte(String v) {
        if (v.isEmpty()) return null;
        if (!v.matches("[A-Z]\\d{8}"))               return "Formato inválido. Ej: N39392288";
        long num = Long.parseLong(v.substring(1));
        if (num < 10_000_000 || num > 60_000_000)   return "Parte numérica entre 10.000.000 y 60.000.000.";
        return null;
    }

    // ---------------------------------------------------------
    //  TELÉFONO: > 6 dígitos, máx MAX_DIGITOS_TELEFONO dígitos,
    //            permite +, (, ), -, espacio
    // ---------------------------------------------------------
    private static String validar_telefono(String v) {
        if (v.isEmpty())                            return "El teléfono es obligatorio.";
        if (!v.matches("[0-9+()\\- ]+"))            return "Solo dígitos y los símbolos + ( ) -";
        long cant_digitos = v.chars().filter(Character::isDigit).count();
        if (cant_digitos < 6)                       return "Debe contener al menos 6 dígitos.";
        if (cant_digitos > MAX_DIGITOS_TELEFONO)    return "Máximo " + MAX_DIGITOS_TELEFONO + " dígitos.";
        return null;
    }

    // ---------------------------------------------------------
    //  CÓDIGO POSTAL: exactamente 4 dígitos
    // ---------------------------------------------------------
    private static String validar_codigo_postal(String v) {
        if (v.isEmpty())                            return "El código postal es obligatorio.";
        if (!v.matches("\\d{4}"))                   return "Debe tener exactamente 4 dígitos.";
        return null;
    }

    // ---------------------------------------------------------
    //  DOMICILIO: máx 50 caracteres
    // ---------------------------------------------------------
    private static String validar_domicilio(String v) {
        if (v.isEmpty())                            return "El domicilio es obligatorio.";
        if (v.length() > 50)                        return "Máximo 50 caracteres.";
        return null;
    }

    // =========================================================
    //  FILTROS DocumentFilter — control en tiempo real
    // =========================================================

    // --- Solo letras (y acentos/ñ), longitud máxima ---
    public static class Filtro_Alfabetico extends DocumentFilter {
        private final int max_len;
        public Filtro_Alfabetico(int max_len) { this.max_len = max_len; }

        @Override
        public void insertString(FilterBypass fb, int off, String str, AttributeSet a)
                throws BadLocationException {
            String filtrado = str.replaceAll("[^a-zA-ZáéíóúÁÉÍÓÚñÑ ]", "");
            if (fb.getDocument().getLength() + filtrado.length() <= max_len)
                super.insertString(fb, off, filtrado, a);
        }

        @Override
        public void replace(FilterBypass fb, int off, int len, String str, AttributeSet a)
                throws BadLocationException {
            String filtrado = str.replaceAll("[^a-zA-ZáéíóúÁÉÍÓÚñÑ ]", "");
            if (fb.getDocument().getLength() - len + filtrado.length() <= max_len)
                super.replace(fb, off, len, filtrado, a);
        }
    }

    // --- Solo dígitos, longitud máxima ---
    public static class Filtro_Numerico extends DocumentFilter {
        private final int max_len;
        public Filtro_Numerico(int max_len) { this.max_len = max_len; }

        @Override
        public void insertString(FilterBypass fb, int off, String str, AttributeSet a)
                throws BadLocationException {
            String filtrado = str.replaceAll("[^0-9]", "");
            if (fb.getDocument().getLength() + filtrado.length() <= max_len)
                super.insertString(fb, off, filtrado, a);
        }

        @Override
        public void replace(FilterBypass fb, int off, int len, String str, AttributeSet a)
                throws BadLocationException {
            String filtrado = str.replaceAll("[^0-9]", "");
            if (fb.getDocument().getLength() - len + filtrado.length() <= max_len)
                super.replace(fb, off, len, filtrado, a);
        }
    }

    // --- Pasaporte: 1ra posición A-Z (forzada mayúscula), resto dígitos, máx 9 ---
    public static class Filtro_Pasaporte extends DocumentFilter {

        @Override
        public void insertString(FilterBypass fb, int off, String str, AttributeSet a)
                throws BadLocationException {
            aplicar(fb, off, 0, str, a);
        }

        @Override
        public void replace(FilterBypass fb, int off, int len, String str, AttributeSet a)
                throws BadLocationException {
            aplicar(fb, off, len, str, a);
        }

        private void aplicar(FilterBypass fb, int off, int len, String entrada, AttributeSet a)
                throws BadLocationException {
            String actual  = fb.getDocument().getText(0, fb.getDocument().getLength());
            String nuevo   = actual.substring(0, off) + entrada + actual.substring(off + len);
            if (nuevo.length() > 9) return;
            if (nuevo.isEmpty())    { super.replace(fb, 0, actual.length(), "", a); return; }

            char primera = Character.toUpperCase(nuevo.charAt(0));
            if (!Character.isLetter(primera)) return;

            String resto = nuevo.substring(1);
            if (!resto.matches("\\d*")) return;

            super.replace(fb, 0, actual.length(), primera + resto, a);
        }
    }

    // --- Teléfono: dígitos + + ( ) - espacio, límite de dígitos ---
    public static class Filtro_Telefono extends DocumentFilter {

        @Override
        public void insertString(FilterBypass fb, int off, String str, AttributeSet a)
                throws BadLocationException {
            String filtrado = str.replaceAll("[^0-9+()\\- ]", "");
            if (contar_digitos(fb, filtrado, 0) <= MAX_DIGITOS_TELEFONO)
                super.insertString(fb, off, filtrado, a);
        }

        @Override
        public void replace(FilterBypass fb, int off, int len, String str, AttributeSet a)
                throws BadLocationException {
            String filtrado = str.replaceAll("[^0-9+()\\- ]", "");
            if (contar_digitos(fb, filtrado, len) <= MAX_DIGITOS_TELEFONO)
                super.replace(fb, off, len, filtrado, a);
        }

        private long contar_digitos(FilterBypass fb, String nuevo, int eliminados)
                throws BadLocationException {
            String actual   = fb.getDocument().getText(0, fb.getDocument().getLength());
            long digitos_actuales = actual.chars().filter(Character::isDigit).count();
            long digitos_eliminados = actual.substring(0, Math.min(eliminados, actual.length()))
                                           .chars().filter(Character::isDigit).count();
            long digitos_nuevos = nuevo.chars().filter(Character::isDigit).count();
            return digitos_actuales - digitos_eliminados + digitos_nuevos;
        }
    }

    // --- Solo longitud máxima, cualquier carácter ---
    public static class Filtro_Longitud extends DocumentFilter {
        private final int max_len;
        public Filtro_Longitud(int max_len) { this.max_len = max_len; }

        @Override
        public void insertString(FilterBypass fb, int off, String str, AttributeSet a)
                throws BadLocationException {
            if (fb.getDocument().getLength() + str.length() <= max_len)
                super.insertString(fb, off, str, a);
        }

        @Override
        public void replace(FilterBypass fb, int off, int len, String str, AttributeSet a)
                throws BadLocationException {
            if (fb.getDocument().getLength() - len + str.length() <= max_len)
                super.replace(fb, off, len, str, a);
        }
    }
}
