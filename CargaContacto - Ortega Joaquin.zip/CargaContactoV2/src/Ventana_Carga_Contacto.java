import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.AbstractDocument;

// =========================================================
//  Ventana_Carga_Contacto v2
//  Diseño: paleta esmeralda/carbón.
//  Nomenclatura: snake_case en todos los identificadores.
// =========================================================
public class Ventana_Carga_Contacto extends JFrame implements ActionListener {

    // --- Campos del formulario ---
    private JTextField campo_nombre;
    private JTextField campo_apellido;
    private JTextField campo_dni;
    private JTextField campo_pasaporte;
    private JTextField campo_telefono;
    private JTextField campo_cod_postal;
    private JTextField campo_domicilio;

    // --- Etiquetas de error ---
    private JLabel error_nombre;
    private JLabel error_apellido;
    private JLabel error_dni;
    private JLabel error_pasaporte;
    private JLabel error_telefono;
    private JLabel error_cod_postal;
    private JLabel error_domicilio;

    // --- Contador de caracteres del teléfono ---
    private JLabel contador_telefono;

    // --- Botones ---
    private JButton btn_aceptar;
    private JButton btn_limpiar;
    private JButton btn_cancelar;

    // =========================================================
    //  PALETA DE COLORES — tema esmeralda/carbón
    // =========================================================
    private static final Color COLOR_BG_VENTANA   = new Color(18,  30,  25);   // Negro verdoso
    private static final Color COLOR_BG_PANEL     = new Color(28,  45,  38);   // Verde carbón
    private static final Color COLOR_BG_CAMPO     = new Color(38,  60,  50);   // Verde medio
    private static final Color COLOR_BG_TITULO    = new Color(22,  160, 133);  // Esmeralda
    private static final Color COLOR_ACENTO       = new Color(26,  188, 156);  // Turquesa brillante
    private static final Color COLOR_LABEL        = new Color(178, 223, 212);  // Verde pálido
    private static final Color COLOR_HINT         = new Color(100, 150, 130);  // Gris verdoso
    private static final Color COLOR_TEXTO        = new Color(236, 252, 247);  // Blanco verdoso
    private static final Color COLOR_ERROR        = new Color(255, 99,  99);   // Rojo suave
    private static final Color COLOR_OK           = new Color(46,  213, 115);  // Verde éxito
    private static final Color COLOR_BTN_ACEPTAR  = new Color(22,  160, 133);  // Esmeralda
    private static final Color COLOR_BTN_LIMPIAR  = new Color(243, 156, 18);   // Ámbar
    private static final Color COLOR_BTN_CANCELAR = new Color(192, 57,  43);   // Rojo oscuro

    // --- Bordes según estado ---
    private static final Border BORDE_NORMAL = BorderFactory.createLineBorder(new Color(50, 90, 70),  1);
    private static final Border BORDE_ERROR  = BorderFactory.createLineBorder(COLOR_ERROR, 2);
    private static final Border BORDE_OK     = BorderFactory.createLineBorder(COLOR_OK,    2);
    private static final Border BORDE_FOCO   = BorderFactory.createLineBorder(COLOR_ACENTO, 2);

    public Ventana_Carga_Contacto() {
        setTitle("Carga de Contacto — v2");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(COLOR_BG_VENTANA);

        construir_ui();
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // =========================================================
    //  construir_ui
    // =========================================================
    private void construir_ui() {
        JPanel panel_raiz = new JPanel(new BorderLayout(0, 0));
        panel_raiz.setBackground(COLOR_BG_VENTANA);

        panel_raiz.add(construir_cabecera(),    BorderLayout.NORTH);
        panel_raiz.add(construir_formulario(),  BorderLayout.CENTER);
        panel_raiz.add(construir_botones(),     BorderLayout.SOUTH);

        add(panel_raiz);
    }

    // --- Cabecera con título y subtítulo ---
    private JPanel construir_cabecera() {
        JPanel panel_cabecera = new JPanel(new BorderLayout());
        panel_cabecera.setBackground(COLOR_BG_TITULO);
        panel_cabecera.setBorder(new EmptyBorder(16, 24, 16, 24));

        JLabel lbl_titulo = new JLabel("📋  Carga de Contacto");
        lbl_titulo.setFont(new Font("Arial", Font.BOLD, 20));
        lbl_titulo.setForeground(Color.WHITE);

        JLabel lbl_subtitulo = new JLabel("Completá los datos del nuevo contacto");
        lbl_subtitulo.setFont(new Font("Arial", Font.PLAIN, 12));
        lbl_subtitulo.setForeground(new Color(178, 230, 220));

        panel_cabecera.add(lbl_titulo,    BorderLayout.NORTH);
        panel_cabecera.add(lbl_subtitulo, BorderLayout.SOUTH);

        return panel_cabecera;
    }

    // --- Formulario central ---
    private JPanel construir_formulario() {
        JPanel panel_form = new JPanel(new GridBagLayout());
        panel_form.setBackground(COLOR_BG_PANEL);
        panel_form.setBorder(new EmptyBorder(18, 26, 10, 26));

        // Instanciar campos
        campo_nombre     = crear_campo(22);
        campo_apellido   = crear_campo(22);
        campo_dni        = crear_campo(10);
        campo_pasaporte  = crear_campo(10);
        campo_telefono   = crear_campo(22);
        campo_cod_postal = crear_campo(6);
        campo_domicilio  = crear_campo(36);

        // Instanciar etiquetas de error
        error_nombre     = crear_label_error();
        error_apellido   = crear_label_error();
        error_dni        = crear_label_error();
        error_pasaporte  = crear_label_error();
        error_telefono   = crear_label_error();
        error_cod_postal = crear_label_error();
        error_domicilio  = crear_label_error();

        // Contador de dígitos para teléfono
        contador_telefono = new JLabel("0 / " + Validador_Campos.MAX_DIGITOS_TELEFONO);
        contador_telefono.setFont(new Font("Arial", Font.PLAIN, 11));
        contador_telefono.setForeground(COLOR_HINT);

        // Aplicar filtros DocumentFilter
        set_filtro(campo_nombre,     new Validador_Campos.Filtro_Alfabetico(20));
        set_filtro(campo_apellido,   new Validador_Campos.Filtro_Alfabetico(20));
        set_filtro(campo_dni,        new Validador_Campos.Filtro_Numerico(8));
        set_filtro(campo_pasaporte,  new Validador_Campos.Filtro_Pasaporte());
        set_filtro(campo_telefono,   new Validador_Campos.Filtro_Telefono());
        set_filtro(campo_cod_postal, new Validador_Campos.Filtro_Numerico(4));
        set_filtro(campo_domicilio,  new Validador_Campos.Filtro_Longitud(50));

        // Actualizar contador de teléfono en tiempo real
        campo_telefono.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e)  { actualizar_contador_tel(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e)  { actualizar_contador_tel(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { actualizar_contador_tel(); }
        });

        // Tooltips
        campo_nombre.setToolTipText("Solo letras · máx. 20 caracteres");
        campo_apellido.setToolTipText("Solo letras · máx. 20 caracteres");
        campo_dni.setToolTipText("8 dígitos entre 10.000.000 y 60.000.000");
        campo_pasaporte.setToolTipText("1 letra A-Z + 8 dígitos · Ej: N39392288");
        campo_telefono.setToolTipText("Más de 6 dígitos · máx. " + Validador_Campos.MAX_DIGITOS_TELEFONO + " · permite + ( ) -");
        campo_cod_postal.setToolTipText("Exactamente 4 dígitos");
        campo_domicilio.setToolTipText("Máx. 50 caracteres");

        // Aplicar FocusListeners + efecto de borde al enfocar
        set_foco(campo_nombre,     error_nombre,     "nombre");
        set_foco(campo_apellido,   error_apellido,   "apellido");
        set_foco(campo_dni,        error_dni,        "dni");
        set_foco(campo_pasaporte,  error_pasaporte,  "pasaporte");
        set_foco(campo_telefono,   error_telefono,   "telefono");
        set_foco(campo_cod_postal, error_cod_postal, "cod_postal");
        set_foco(campo_domicilio,  error_domicilio,  "domicilio");

        // GridBagConstraints
        GridBagConstraints g = new GridBagConstraints();
        g.insets  = new Insets(3, 6, 0, 6);
        g.anchor  = GridBagConstraints.WEST;

        // --- Sección: Datos personales ---
        int fila = 0;
        agregar_separador(panel_form, g, fila++, "▸  Datos personales");
        agregar_fila(panel_form, g, fila++, "Nombre:",      campo_nombre,     error_nombre,
                     "máx. 20 letras", null);
        agregar_fila(panel_form, g, fila++, "Apellido:",    campo_apellido,   error_apellido,
                     "máx. 20 letras", null);

        // --- Sección: Identificación ---
        agregar_separador(panel_form, g, fila++, "▸  Identificación  (solo uno)");
        agregar_fila(panel_form, g, fila++, "DNI:",         campo_dni,        error_dni,
                     "8 dígitos · 10M–60M", null);
        agregar_fila(panel_form, g, fila++, "Pasaporte:",   campo_pasaporte,  error_pasaporte,
                     "ej: N39392288", null);

        // --- Sección: Contacto ---
        agregar_separador(panel_form, g, fila++, "▸  Datos de contacto");
        agregar_fila(panel_form, g, fila++, "Teléfono:",    campo_telefono,   error_telefono,
                     "6–" + Validador_Campos.MAX_DIGITOS_TELEFONO + " dígitos · + ( ) -", contador_telefono);
        agregar_fila(panel_form, g, fila++, "Cód. Postal:", campo_cod_postal, error_cod_postal,
                     "4 dígitos", null);
        agregar_fila(panel_form, g, fila++, "Domicilio:",   campo_domicilio,  error_domicilio,
                     "máx. 50 caracteres", null);

        return panel_form;
    }

    // --- Agrega un separador de sección con título ---
    private void agregar_separador(JPanel panel, GridBagConstraints g, int fila, String texto) {
        g.gridx = 0; g.gridy = fila * 2;
        g.gridwidth = 2;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(12, 6, 4, 6);

        JPanel sep_panel = new JPanel(new BorderLayout(8, 0));
        sep_panel.setBackground(COLOR_BG_PANEL);

        JLabel sep_lbl = new JLabel(texto);
        sep_lbl.setFont(new Font("Arial", Font.BOLD, 12));
        sep_lbl.setForeground(COLOR_ACENTO);

        JSeparator linea = new JSeparator();
        linea.setForeground(new Color(50, 100, 80));
        linea.setBackground(COLOR_BG_PANEL);

        sep_panel.add(sep_lbl,  BorderLayout.WEST);
        sep_panel.add(linea,    BorderLayout.CENTER);

        panel.add(sep_panel, g);

        g.gridwidth = 1;
        g.insets = new Insets(3, 6, 0, 6);
        g.fill = GridBagConstraints.NONE;
    }

    // --- Agrega una fila: label | campo + hint/extra | error ---
    private void agregar_fila(JPanel panel, GridBagConstraints g,
                               int fila, String texto_label,
                               JTextField campo, JLabel error_label,
                               String hint, JLabel extra_label) {
        // Columna 0: etiqueta
        g.gridx = 0; g.gridy = fila * 2;
        g.fill = GridBagConstraints.NONE;
        g.weightx = 0;
        JLabel lbl = new JLabel(texto_label);
        lbl.setFont(new Font("Arial", Font.BOLD, 13));
        lbl.setForeground(COLOR_LABEL);
        lbl.setPreferredSize(new Dimension(100, 20));
        panel.add(lbl, g);

        // Columna 1: campo + hint + extra (ej: contador)
        g.gridx = 1; g.gridy = fila * 2;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1.0;

        JPanel wrap = new JPanel(new BorderLayout(8, 0));
        wrap.setBackground(COLOR_BG_PANEL);

        JLabel hint_lbl = new JLabel(hint);
        hint_lbl.setFont(new Font("Arial", Font.ITALIC, 11));
        hint_lbl.setForeground(COLOR_HINT);

        wrap.add(campo,    BorderLayout.WEST);
        wrap.add(hint_lbl, BorderLayout.CENTER);
        if (extra_label != null)
            wrap.add(extra_label, BorderLayout.EAST);

        panel.add(wrap, g);

        // Fila de error
        g.gridx = 1; g.gridy = fila * 2 + 1;
        g.insets = new Insets(1, 6, 4, 6);
        panel.add(error_label, g);
        g.insets = new Insets(3, 6, 0, 6);
    }

    // --- Panel de botones en la parte inferior ---
    private JPanel construir_botones() {
        JPanel panel_btn = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 14));
        panel_btn.setBackground(new Color(18, 30, 25));
        panel_btn.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(40, 80, 60)));

        btn_aceptar  = crear_boton("✔  Aceptar",   COLOR_BTN_ACEPTAR);
        btn_limpiar  = crear_boton("↺  Limpiar",   COLOR_BTN_LIMPIAR);
        btn_cancelar = crear_boton("✖  Cancelar",  COLOR_BTN_CANCELAR);

        btn_aceptar.addActionListener(this);
        btn_limpiar.addActionListener(this);
        btn_cancelar.addActionListener(this);

        panel_btn.add(btn_aceptar);
        panel_btn.add(btn_limpiar);
        panel_btn.add(btn_cancelar);
        return panel_btn;
    }

    // =========================================================
    //  actionPerformed
    // =========================================================
    @Override
    public void actionPerformed(ActionEvent e) {
        if      (e.getSource() == btn_aceptar)  accion_aceptar();
        else if (e.getSource() == btn_limpiar)  accion_limpiar();
        else if (e.getSource() == btn_cancelar) System.exit(0);
    }

    // --- Aceptar: valida todos y muestra resumen ---
    private void accion_aceptar() {
        boolean ok = true;
        ok &= validar(campo_nombre,     error_nombre,     "nombre");
        ok &= validar(campo_apellido,   error_apellido,   "apellido");
        ok &= validar(campo_dni,        error_dni,        "dni");
        ok &= validar(campo_pasaporte,  error_pasaporte,  "pasaporte");
        ok &= validar(campo_telefono,   error_telefono,   "telefono");
        ok &= validar(campo_cod_postal, error_cod_postal, "cod_postal");
        ok &= validar(campo_domicilio,  error_domicilio,  "domicilio");
        ok &= validar_exclusividad_dni_pasaporte();

        if (ok) {
            mostrar_resumen();
        } else {
            JOptionPane.showMessageDialog(this,
                "Hay campos con errores. Por favor corregílos antes de continuar.",
                "Formulario inválido",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    // --- Limpiar: resetea todo ---
    private void accion_limpiar() {
        JTextField[] campos  = { campo_nombre, campo_apellido, campo_dni,
                                 campo_pasaporte, campo_telefono, campo_cod_postal, campo_domicilio };
        JLabel[]     errores = { error_nombre, error_apellido, error_dni,
                                 error_pasaporte, error_telefono, error_cod_postal, error_domicilio };
        for (int i = 0; i < campos.length; i++) {
            campos[i].setText("");
            set_borde(campos[i], BORDE_NORMAL);
            errores[i].setText(" ");
        }
        contador_telefono.setText("0 / " + Validador_Campos.MAX_DIGITOS_TELEFONO);
        contador_telefono.setForeground(COLOR_HINT);
        campo_nombre.requestFocus();
    }

    // --- Resumen de datos cargados ---
    private void mostrar_resumen() {
        StringBuilder sb = new StringBuilder("✔  Contacto guardado correctamente\n\n");
        sb.append("Nombre:       ").append(campo_nombre.getText()).append("\n");
        sb.append("Apellido:     ").append(campo_apellido.getText()).append("\n");
        if (!campo_dni.getText().isEmpty())
            sb.append("DNI:          ").append(campo_dni.getText()).append("\n");
        if (!campo_pasaporte.getText().isEmpty())
            sb.append("Pasaporte:    ").append(campo_pasaporte.getText()).append("\n");
        sb.append("Teléfono:     ").append(campo_telefono.getText()).append("\n");
        sb.append("Cód. Postal:  ").append(campo_cod_postal.getText()).append("\n");
        sb.append("Domicilio:    ").append(campo_domicilio.getText()).append("\n");

        JOptionPane.showMessageDialog(this, sb.toString(),
                "Contacto guardado", JOptionPane.INFORMATION_MESSAGE);
    }

    // =========================================================
    //  Validaciones por FocusListener
    // =========================================================
    private void set_foco(JTextField campo, JLabel error_label, String tipo) {
        campo.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                // Resaltar borde al enfocar si no hay error
                if (error_label.getText().isBlank())
                    set_borde(campo, BORDE_FOCO);
            }

            @Override
            public void focusLost(FocusEvent e) {
                validar(campo, error_label, tipo);
                if (tipo.equals("dni") || tipo.equals("pasaporte"))
                    validar_exclusividad_dni_pasaporte();
            }
        });
    }

    private boolean validar(JTextField campo, JLabel error_label, String tipo) {
        String valor = campo.getText().trim();
        String error = Validador_Campos.validar(valor, tipo);
        if (error != null) {
            marcar_error(campo, error_label, error);
            return false;
        }
        marcar_ok(campo, error_label);
        return true;
    }

    // --- Exclusividad: DNI y Pasaporte no pueden coexistir ---
    private boolean validar_exclusividad_dni_pasaporte() {
        String val_dni = campo_dni.getText().trim();
        String val_pas = campo_pasaporte.getText().trim();
        String msg_exc = "DNI y Pasaporte no pueden tener valor al mismo tiempo.";

        if (!val_dni.isEmpty() && !val_pas.isEmpty()) {
            marcar_error(campo_dni,       error_dni,       msg_exc);
            marcar_error(campo_pasaporte, error_pasaporte, msg_exc);
            return false;
        }
        if (val_dni.isEmpty() && error_dni.getText().contains("mismo tiempo"))
            marcar_ok(campo_dni, error_dni);
        if (val_pas.isEmpty() && error_pasaporte.getText().contains("mismo tiempo"))
            marcar_ok(campo_pasaporte, error_pasaporte);
        return true;
    }

    // --- Actualiza contador de dígitos del teléfono ---
    private void actualizar_contador_tel() {
        String texto = campo_telefono.getText();
        long cant_digitos = texto.chars().filter(Character::isDigit).count();
        contador_telefono.setText(cant_digitos + " / " + Validador_Campos.MAX_DIGITOS_TELEFONO);
        if (cant_digitos > Validador_Campos.MAX_DIGITOS_TELEFONO)
            contador_telefono.setForeground(COLOR_ERROR);
        else if (cant_digitos >= 6)
            contador_telefono.setForeground(COLOR_OK);
        else
            contador_telefono.setForeground(COLOR_HINT);
    }

    // =========================================================
    //  Helpers visuales
    // =========================================================
    private void marcar_error(JTextField campo, JLabel lbl, String msg) {
        set_borde(campo, BORDE_ERROR);
        lbl.setText("✖  " + msg);
        lbl.setForeground(COLOR_ERROR);
    }

    private void marcar_ok(JTextField campo, JLabel lbl) {
        set_borde(campo, campo.getText().trim().isEmpty() ? BORDE_NORMAL : BORDE_OK);
        lbl.setText(" ");
    }

    private void set_borde(JTextField campo, Border borde) {
        campo.setBorder(new CompoundBorder(borde, new EmptyBorder(4, 7, 4, 7)));
    }

    // =========================================================
    //  Fábricas de componentes
    // =========================================================
    private JTextField crear_campo(int columnas) {
        JTextField f = new JTextField(columnas);
        f.setFont(new Font("Consolas", Font.PLAIN, 13));
        f.setBackground(COLOR_BG_CAMPO);
        f.setForeground(COLOR_TEXTO);
        f.setCaretColor(COLOR_ACENTO);
        f.setSelectionColor(COLOR_ACENTO);
        set_borde(f, BORDE_NORMAL);
        return f;
    }

    private JLabel crear_label_error() {
        JLabel l = new JLabel(" ");
        l.setFont(new Font("Arial", Font.ITALIC, 11));
        l.setForeground(COLOR_ERROR);
        return l;
    }

    private JButton crear_boton(String texto, Color color) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Arial", Font.BOLD, 13));
        b.setBackground(color);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(true);
        b.setPreferredSize(new Dimension(138, 38));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Efecto hover
        Color color_hover = color.darker();
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setBackground(color_hover); }
            public void mouseExited(MouseEvent e)  { b.setBackground(color); }
        });
        return b;
    }

    private void set_filtro(JTextField campo, javax.swing.text.DocumentFilter filtro) {
        ((AbstractDocument) campo.getDocument()).setDocumentFilter(filtro);
    }

    // =========================================================
    //  Main
    // =========================================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Ventana_Carga_Contacto());
    }
}
